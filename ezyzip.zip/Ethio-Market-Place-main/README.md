# ⚡️ Ethio Market Place ⚡️

## Admin Signin Page

<img src="screenshots/admin_signin.PNG" style="width:100%" alt="Er Diagram"/>

## Admin Category List Page

<img src="screenshots/category_list.PNG" style="width:100%" alt="category"/>

## Admin Category Create Page

<img src="screenshots/category_create.PNG" style="width:100%" alt="category"/>

## Admin Category Update Page

<img src="screenshots/category_update.PNG" style="width:100%" alt="category"/>

## Admin Sub Category List Page

<img src="screenshots/sub_category_list.PNG" style="width:100%" alt="category"/>

## Admin Merchant Update Page

<img src="screenshots/merchant_update.PNG" style="width:100%" alt="category"/>

## Admin Merchant Create Page

<img src="screenshots/merchant_create.PNG" style="width:100%" alt="category"/>

## Admin Merchant List Page

<img src="screenshots/merchant_list.PNG" style="width:100%" alt="category"/>

## Searching Sorting and Pagination Features

<img src="screenshots/category_searching.PNG" style="width:100%" alt="category"/>

## Add Product Page With Dynamic Content and Media

<img src="screenshots/product_create.png" style="width:100%" alt="category"/>

## Product List Page

<img src="screenshots/product_list.png" style="width:100%" alt="Products"/>

## Product Edit Page

<img src="screenshots/product_edit.png" style="width:100%" alt="Products"/>

## Product Add Media Page

<img src="screenshots/product_add_media.png" style="width:100%" alt="Products"/>

## Product Edit Media Page

<img src="screenshots/product_edit_media.png" style="width:100%" alt="Products"/>

## Product Add Stock Page

<img src="screenshots/product_add_stock.png" style="width:100%" alt="Products"/>
