from django.contrib import admin
from DjangoEcommerceApp.models import Categories,SubCategories

# Register your models here.
admin.site.register(Categories)
admin.site.register(SubCategories)