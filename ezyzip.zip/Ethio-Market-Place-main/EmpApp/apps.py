from django.apps import AppConfig


class DjangoecommerceappConfig(AppConfig):
    name = 'DjangoEcommerceApp'
